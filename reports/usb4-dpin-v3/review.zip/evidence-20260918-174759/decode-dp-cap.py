#!/usr/bin/env python3
# Usage: sudo cat .../port5/regs | python3 decode-dp-cap.py   (decodes DP adapter cap id 4)
import sys
rate = {0:'RBR',1:'HBR',2:'HBR2',3:'HBR3'}
lanes = {0:1,1:2,2:4}
regs = {}
for line in sys.stdin:
    p = line.split()
    if len(p) == 5 and p[2] == '0x04':
        regs[int(p[1])] = int(p[4], 16)
def cap(v): return f"rate={rate.get((v>>8)&0xf,'?')} lanes={lanes.get((v>>12)&7,'?')} DPRX_DONE={(v>>31)&1}"
if 0 in regs:  print(f"ADP_DP_CS_0 = {regs[0]:#010x}  VE={ (regs[0]>>31)&1 } AE={ (regs[0]>>30)&1 } video_hopid={ (regs[0]>>16)&0x7ff }")
if 2 in regs:  print(f"ADP_DP_CS_2 = {regs[2]:#010x}  HPD={ (regs[2]>>6)&1 }")
if 4 in regs:  print(f"DP_LOCAL_CAP  = {regs[4]:#010x}  {cap(regs[4])}")
if 5 in regs:  print(f"DP_REMOTE_CAP = {regs[5]:#010x}  {cap(regs[5])}")
if 6 in regs:  print(f"DP_STATUS   = {regs[6]:#010x}  allocated_bw={ (regs[6]>>24)&0xff }")
if 7 in regs:  print(f"DP_COMMON_CAP = {regs[7]:#010x}  {cap(regs[7])}")
if 8 in regs:  print(f"ADP_DP_CS_8 = {regs[8]:#010x}  requested_bw={ regs[8]&0xff }")
