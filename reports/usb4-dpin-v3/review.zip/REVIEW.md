# Adversarial review packet — DP-over-Thunderbolt on M1 Air

Purpose: give a skeptical reviewer everything needed to **confirm or refute** the central claim,
with reproducible commands and captured evidence. Written to be attacked. If a claim below is not
backed by evidence you can re-run, treat it as unproven.

Evidence bundle for this packet: `reports/usb4-dpin-v3/evidence-20260918-174759/`
(captured live, DP-IN v3 boot, tunnel connected). Every file cited below is in that directory.
Companion docs: `HANDOFF.md` (how to reproduce/continue), memory `dpin-failure-analysis.md`
(history, including two retracted overclaims).

## The claim under review

**CLAIMED (with proof below):**
1. Thunderbolt/USB4 transport is up: the Apple host NHI is live and the LG UltraFine's Thunderbolt
   router is enumerated and **authorized**.
2. A **DisplayPort tunnel** is established through Thunderbolt, and the **DP main link is trained
   and locked at the monitor's own DP receiver** (not merely an AUX sideband ping).
3. The host reads the monitor's real **EDID** over that tunnel; the DRM connector `DP-1` comes up
   **connected** with the monitor's true modes.

**NOT CLAIMED / explicitly unproven:**
4. A visible picture. The panel is dark (webcam-verified). We do **not** claim pixels drive the
   LCD. Evidence points to the monitor's internal scaler/backlight board being unpowered because it
   is USB-managed and there is no USB (see "the wall").
5. Any DP bandwidth-allocation defect. An earlier note claimed "consumed bandwidth 0" was the
   blocker — **retracted**, it was a stale log line printed before DPRX completed.

The honest one-liner: *Thunderbolt transport + DP tunnel + link-lock at the monitor + EDID are
proven; a working picture is not, and is gated on an unimplemented USB/PCIe-tunnel path.*

## Proof, claim by claim

### Claim 1 — TB transport up, LG router authorized
File `02-thunderbolt-devices.txt`:
```
== 0-0   device_name=iOS  vendor_name=Apple Inc.  authorized=1  generation=4   (host router / NHI)
== 0-1   device_name=UltraFine 4K  vendor_name=LG Electronics  authorized=1  generation=3
         rx_speed=10.0 Gb/s  tx_speed=10.0 Gb/s  rx_lanes=2  tx_lanes=2
         unique_id=c5030000-0082-840e-038c-8b3a84c29000
```
Reproduce:
```sh
for d in /sys/bus/thunderbolt/devices/*; do echo $d; cat $d/authorized $d/device_name 2>/dev/null; done
```
Adversary check: `authorized=1` on a device that reports `vendor_name=LG Electronics` and negotiated
20 Gb/s (2 lanes x 10) is the OS Thunderbolt stack having enumerated the real remote router over the
wire. `sysfs` populates these only from live router config-space reads.

### Claim 2 — DP tunnel established AND main link locked at the monitor
Two independent signals.

(a) The thunderbolt connection manager built and activated the DP tunnel `0:5 <-> 1:10`.
File `05-journal-tunnel.txt` contains the path-activation and:
```
thunderbolt-apple-nhi 501f00000.nhi: 0:5 <-> 1:10 (DP): DPRX capabilities read completed
```

(b) The DP adapter config-space (Thunderbolt TB_CFG_PORT) proves the **main link is locked at the
sink**. File `03-hostDPIN-port5-regs.txt`, capability id 4 (the DP adapter cap), decoded against
`sources/linux-usb4-backport/drivers/thunderbolt/tb_regs.h`:
```
rel0 ADP_DP_CS_0    = 0xc0090400  -> VE(bit31)=1  AE(bit30)=1  video_hopid=9
rel7 DP_COMMON_CAP  = 0xaa402214  -> rate=HBR2  lanes=4  DPRX_DONE(bit31)=1
```
`DP_COMMON_CAP.DPRX_DONE=1` is the load-bearing bit: per the USB4/TB DP spec and the driver code
(`tb_dp_read_cap`/`tb_dp_wait_dprx` in `drivers/thunderbolt/tunnel.c`), it is set only after the DP
IN adapter has **read the DisplayPort receiver capability (DPCD) of the sink through the trained
main link**. That cannot succeed unless the main link is trained and locked at the monitor's DP
receiver. LG DP-OUT side, `03-lgDPOUT-port10-regs.txt` cap 4:
```
rel0 ADP_DP_CS_0 = 0xc009044f -> VE=1  (monitor's DP-OUT adapter has video enabled)
rel2 ADP_DP_CS_2 = 0x000fff40 -> HPD(bit6)=1  (monitor asserts hot-plug)
rel6 DP_STATUS   = 0x04000204 -> allocated_bw(31:24)=4
```
Reproduce:
```sh
sudo cat /sys/kernel/debug/thunderbolt/0-0/port5/regs   | awk '$3=="0x04"'
sudo cat /sys/kernel/debug/thunderbolt/0-1/port10/regs  | awk '$3=="0x04"'
```
Adversary check / threats to validity:
- "DPRX_DONE could be stale from a prior boot." No — the register lives in the adapter that only
  exists while the tunnel exists; a `disconnect` clears it and it re-sets on reconnect (see the
  attempt logs). It also reads back live each time.
- "rate/lanes could be a default, not negotiated." The negotiated `DP_COMMON_CAP` (HBR2/4) is the
  min of LOCAL (rel4, HBR3-capable) and REMOTE (rel5, from the monitor), i.e. an actual exchange.
- "Maybe there is no real tunnel, just adapters." The connection-manager journal shows the video +
  AUX path hops being written across two routers (`0:5` host, `1:10` device), and `authorized=1` +
  20 Gb/s link on `0-1` is a live remote router.

### Claim 3 — real EDID + DRM connector up
File `04-drm-dp1.txt`: `status=connected`, 7 modes incl. 3840x2160. File `04-dp1.edid` (384 bytes).
Decoded:
```
valid EDID header: True
manufacturer (PnP ID): GSM        (= LG Electronics' assigned EDID vendor code)
monitor name: LG UltraFine
serial: 010NTAB3E384
```
Reproduce:
```sh
cat /sys/class/drm/card2-DP-1/status /sys/class/drm/card2-DP-1/modes
sudo cat /sys/class/drm/card2-DP-1/edid | wc -c        # 384
# decode: python3 with the EDID header/vendor/descriptor parse in this packet
```
Adversary check: the EDID is not fabricated or cached from elsewhere — its embedded serial
`010NTAB3E384` matches the serial Hyprland independently reported for DP-1
(`description: LG Electronics LG UltraFine 010NTAB3E384`). A 384-byte EDID (base block + 1
extension) with a valid header and matching serial is a genuine read from this specific panel.

## The wall (why claim 4 is NOT met) — also evidenced

File `06-pcie-usb-negative.txt`:
```
## PCI devices  -> only 3, all built-in (Apple bridge + Broadcom wifi/bt). No tunneled PCIe device.
0000:00:00.0 0x106b:0x100c
0000:01:00.0 0x14e4:0x4425
0000:01:00.1 0x14e4:0x5f69
## USB devices  -> (none)   No tunneled USB.
## PCIe tunnel failure
0:3 <-> 1:8 (PCI): activation failed
1:8: PCIe tunnel activation failed, aborting
PCIe Down path activation failed: -107
```
The LG router exposes DP + PCIe but **no native USB3 adapter** (see `HANDOFF.md`), so the monitor's
USB (its control HID + hub, named in `reports/macos-dump/ioreg.txt` as "LG UltraFine Display
Controls" / hubs) is reachable only via a PCIe tunnel. That tunnel fails (`-107`), and there is no
host tunneled-PCIe root complex in the Linux device tree
(`/proc/device-tree/soc/cio@501ac0000/` has only `nhi`, `iommu`, `ports/port@1`). Webcam frames
(`scripts/webcam-snap.sh`, Read the jpg) show a dark panel with no faint LCD image under ambient
light. Therefore: DP video reaches the monitor's DP input, but the monitor's USB-managed internal
display board does not light the LCD.

## What a reviewer should independently re-run

On the DP-IN v3 boot (`uname -r` = `7.1.13-usb4-gpu-test`), with the LG on the front port:
```sh
cd /home/mert/Work/omarchy-mac-external-monitor
sudo python3 scripts/run-dpin-v3.py disconnect
sudo artifacts/mmio/mmio-rw w 501e5000c 0 && sudo artifacts/mmio/mmio-rw p 501e50010 0 1 500
sudo python3 scripts/run-dpin-v3.py connect reports/usb4-dpin-v3/review-recheck --dpin 0
# then re-capture claim-2/3 evidence:
sudo cat /sys/kernel/debug/thunderbolt/0-0/port5/regs | awk '$3=="0x04"'   # expect DPRX_DONE=1
sudo cat /sys/class/drm/card2-DP-1/edid | wc -c                            # expect 384, serial 010NTAB3E384
bash scripts/webcam-snap.sh && : # Read the jpg: expect DARK panel (claim 4 stays unmet)
```
If any expected result differs, the corresponding claim is refuted — please record which.

## Known weaknesses of this evidence (stated up front)

- The whole result depends on a manual `/dev/mem` register write (`501e5000c`) done from userspace;
  it is not yet in-kernel. A reviewer could argue it is fragile. True — it is a bring-up hack, not a
  driver. It is reproducible and non-persistent (a reboot clears it).
- `DPRX_DONE=1` proves link-lock at the sink but not that the monitor is scanning pixels to the LCD.
  We do not claim it does. The dark panel is consistent with the USB-gated scaler theory but is not
  a positive proof of *where* between DP-input and LCD the pixels stop; distinguishing that would
  need either a working USB path or an m1n1 MMIO trace of macOS.
- All macOS-side references (USB device names, ACIO PCIe properties) come from a static ioreg/ADT
  dump in `reports/macos-dump/`, not a live trace. They establish how macOS is wired, not a
  guarantee Linux must match bit-for-bit.
